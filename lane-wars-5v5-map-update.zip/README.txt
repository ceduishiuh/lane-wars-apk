LANE WARS 5V5 - MAP DETAIL UPDATE
=================================
What's new on the map
- Textured ground: mottled grass, tufts, flower patches, pebbles, mossy boulders, rocky cliff edge around the map
- Cobblestone lanes with kerb stones, worn centre line, blue/red team tint toward each base, lit torches
- Wooden plank bridges where the 3 lanes cross the river
- Detailed river: banks, flowing highlights, foam, reeds, lily pads, animated ripples, sand shoals at the crab spots
- Dirt jungle clearings with pebble rings and winding trails between camps
- Serpent / Dragon pits as rune-ringed stone craters with pulsing glow
- Stone base plazas with team-coloured inlays, pillars and animated braziers
- Leafy bushes (gently swaying, with flowers) and layered tree canopies with shadows
- Brick + moss jungle walls
Gameplay, hitboxes and bush/vision logic are unchanged - visuals only.

How to use
1) Android: copy the 3 files in app/src/main/assets/ over your project's app/src/main/assets/ and rebuild the APK.
   (Only game.js changed; index.html and style.css are the originals.)
2) Quick preview on PC: open play-in-browser/index.html in Chrome.
map_detail_pack_only.js = just the new code, if you want to paste it at the end of your own game.js.
