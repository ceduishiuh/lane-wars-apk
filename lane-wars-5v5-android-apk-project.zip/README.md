# Lane Wars 5v5 — Offline Android APK Project

This project packages the complete **Lane Wars 5v5** HTML5 arena game (`index.html`, `style.css`, and `game.js`) inside a native landscape Android `WebView` using `WebViewAssetLoader`. All 70+ heroes, bot AI, audio synthesis, and `localStorage` saves (`lw_hist`, `lw_mast`, `lw_rank`, `lw_tour8`, `lw_cos`, `lw_set`) run 100% offline with zero network permissions.

## Option 1: Build APK via GitHub Actions (No Android Studio Needed)
1. Unzip this archive and create a new repository on GitHub.
2. Upload/push all project files (including the hidden `.github/workflows/build-apk.yml` folder) to your `main` branch.
3. Open your GitHub repository **Actions** tab → click **Build Offline Android APK** (auto-runs on push, or click **Run workflow**).
4. Once finished (~2 minutes), scroll to **Artifacts** and download **lane-wars-5v5-offline-release-apk** (optimized R8 build) or **lane-wars-5v5-offline-debug-apk**.
5. Unzip the downloaded artifact and install the `.apk` file on your Android phone.

> **Important if uploading via GitHub Web UI:** Make sure hidden folders like `.github` are visible when dragging files into GitHub's upload box, or push using Git CLI (`git add . && git commit -m "init" && git push`) so `.github/workflows/build-apk.yml` is included.

## Option 2: Build Locally with Android Studio or Gradle CLI
1. Open this unzipped folder in **Android Studio**.
2. Wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Or run from terminal (requires JDK 17, Gradle 8.10+, and Android SDK 35):
   ```bash
   gradle assembleRelease
   ```
   Output APK: `app/build/outputs/apk/release/app-release.apk`.
