LANE WARS 5V5 - MAP DETAIL UPDATE
=================================
What's new on the map
- Textured ground: mottled grass, tufts, flower patches, pebbles, mossy boulders, rocky cliff edge around the map
- Cobblestone lanes with kerb stones, worn centre line, blue/red team tint toward each base, lit torches
- Wooden plank bridges where the 3 lanes cross the river
- Detailed river: banks, flowing highlights, foam, reeds, lily pads, animated ripples, sand shoals at the crab spots
- Dirt jungle clearings with pebble rings and winding trails between camps
- Serpent / Dragon pits as rune-ringed stone craters with pulsing glow
- Stone base plazas with team-coloured inlays, pillars and animated braziers
- Leafy bushes (gently swaying, with flowers) and layered tree canopies with shadows
- Brick + moss jungle walls
Gameplay, hitboxes and bush/vision logic are unchanged - visuals only.

How to use
1) Android: copy the 3 files in app/src/main/assets/ over your project's app/src/main/assets/ and rebuild the APK.
   (Only game.js changed; index.html and style.css are the originals.)
2) Quick preview on PC: open play-in-browser/index.html in Chrome.
map_detail_pack_only.js = just the new code, if you want to paste it at the end of your own game.js.


LOGO UPDATE
- Game logo added to the main menu (logo.png) and as browser/tab favicon (favicon.png) - copy with the other assets files.
- android-icons/res/mipmap-*/ : app launcher icons. Copy the mipmap-* folders into app/src/main/res/ (replace ic_launcher.png / ic_launcher_round.png).
  If your project uses adaptive icons (mipmap-anydpi-v26/ic_launcher.xml), delete that file so these PNGs are used.
- android-icons/play-store-icon-512.png : 512px icon for Google Play.

HERO LOOK REWORK
- Kraken, Yeti, Galeforce, Ravager are now humanoid heroes (no more animal sprites):
  Kraken = brass deep-sea diver with trident + air tank; Yeti = frost giant with fur hood, fur mantle and ice club;
  Galeforce = wind archer with feathered cap + quiver; Ravager = mohawk street-brawler with claws + belt.
- New hat styles: divehelm, furhood, feather, bandana, mohawk, turban, coral, kabuto, visor.
- New accessories: quiver, furmantle. New weapon: iceclub.
- ~35 other heroes got different hats / accessories / body sizes (LOOK table in game.js, search "const LOOK") so silhouettes differ.
- To tweak any hero, edit its entry in the PR table (look string) or LOOK table.

BODY BUILDS (v3)
- Heroes no longer share one skeleton. Each hero has its own build in the BUILD table in game.js (search "const BUILD"):
  tw = torso/shoulder width, lw = leg thickness, aw = arm thickness, lg = leg length (+ longer / - shorter),
  belly = paunch, robe = long flowing gown (number = flare, negative = tapering), skirt = short coat/skirt over legs.
- Builds range from slim/tall (Assassin, Lancer, Clinkz) through robed casters (Mage, Cleric, Oracle) and stocky/dwarfish
  (Tinkerer, Bombardier, Alchemist) to hulks (Golem, Yeti, Juggernaut, Barbarian).
- Heroes still on animal sprites: Spidermom, Twinfang, Nightstalker, Huntress.
