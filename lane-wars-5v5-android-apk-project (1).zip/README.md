# Lane Wars 5v5 — Offline Android APK Project

This project packages the complete **Lane Wars 5v5** HTML5 arena game (`index.html`, `style.css`, and `game.js`) inside a native landscape Android `WebView` using `WebViewAssetLoader`. All 70+ heroes, bot AI, audio synthesis, and `localStorage` saves (`lw_hist`, `lw_mast`, `lw_rank`, `lw_tour8`, `lw_cos`, `lw_set`) run 100% offline with zero network permissions.

## Option 1: Build from a Mobile Phone (No Unzip Needed)
1. Download `lane-wars-5v5-android-apk-project.zip` on your phone (**do not unzip it**).
2. On GitHub, open your repository and tap **Add file → Upload files**, upload the single `.zip` file, and commit.
3. Open **Actions → set up a workflow yourself** (or edit `.github/workflows/main.yml`), paste the contents of `.github/workflows/build-apk.yml`, and commit.
4. GitHub Actions automatically unzips the archive, compiles the APK, and attaches **lane-wars-5v5-offline-release-apk** under **Artifacts**.

## Option 2: Push Unzipped Folder (Desktop / Git CLI)
1. Unzip this archive and push all files (including `.github/workflows/build-apk.yml`) to `main`.
2. Open the **Actions** tab and download **lane-wars-5v5-offline-release-apk** from **Artifacts**.

## Option 3: Build Locally with Android Studio or Gradle CLI
1. Open this unzipped folder in **Android Studio**.
2. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Or run from terminal (requires JDK 17, Gradle 8.10+, and Android SDK 35):
   ```bash
   gradle assembleRelease
   ```
   Output APK: `app/build/outputs/apk/release/app-release.apk`.
