
/* ===== MAP DETAIL PACK: richer terrain, river, bridges, lane stones, base plazas, pits, bushes, trees, torches ===== */
try{(function(){
const S=0.5,MW=Math.round(W*S),MH=Math.round(H*S);
const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
const mul=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const SPT=[2400,1000],DPT=[2400,1700];
let BG=null,OV=null,TORCH=[],BRZ=[],BUILT=false,FAIL=false;

function samp(poly,step){
const pts=[];
for(let i=0;i<poly.length-1;i++){
const a=poly[i],b=poly[i+1],dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy)||1,n=Math.max(1,Math.floor(L/step));
for(let k=0;k<n;k++){const t=k/n;pts.push({x:a[0]+dx*t,y:a[1]+dy*t,tx:dx/L,ty:dy/L,nx:-dy/L,ny:dx/L});}
}
return pts;
}
function wavy(g,x0,x1,amp,ph,fill){
g.beginPath();
for(let y=-20;y<=H+20;y+=24)g.lineTo(x0+Math.sin(y*.011+ph)*amp+Math.sin(y*.027+ph*2)*amp*.4,y);
for(let y=H+20;y>=-20;y-=24)g.lineTo(x1+Math.sin(y*.013+ph+1.3)*amp+Math.sin(y*.031+ph)*amp*.4,y);
g.closePath();g.fillStyle=fill;g.fill();
}
function ell(g,x,y,rx,ry,rot,col){g.fillStyle=col;g.beginPath();g.ellipse(x,y,rx,ry,rot,0,6.2832);g.fill();}

/* ---------- BACKGROUND (under lanes) ---------- */
function buildBG(){
BG=mk(MW,MH);const g=BG.getContext('2d');g.scale(S,S);const r=mul(1337);
// base ground gradient: cool blue-green on blue side, warm olive on red side
let gr=g.createLinearGradient(0,0,W,0);
gr.addColorStop(0,'#1f3a33');gr.addColorStop(.35,'#25392b');gr.addColorStop(.5,'#27382a');gr.addColorStop(.65,'#2b3a28');gr.addColorStop(1,'#37392a');
g.fillStyle=gr;g.fillRect(0,0,W,H);
// large soft mottling
const mot=['rgba(70,120,70,','rgba(20,50,30,','rgba(110,140,70,','rgba(30,70,60,','rgba(90,90,50,'];
for(let i=0;i<1500;i++){
const x=r()*W,y=r()*H,rx=40+r()*150,ry=rx*(.4+r()*.5);
ell(g,x,y,rx,ry,r()*3.14,mot[i%5]+(.035+r()*.06).toFixed(3)+')');
}
// mown grass stripes (subtle)
for(let x=0;x<W;x+=160){g.fillStyle=(x/160|0)%2?'rgba(255,255,255,.018)':'rgba(0,0,0,.025)';g.fillRect(x,0,160,H);}
// jungle clearings + trails
const CPS=[[1050,920],[680,820],[1820,860],[2120,760],[1050,1780],[680,1880],[1820,1840],[2120,1940]];
const all=[];CPS.forEach(c=>{all.push(c);all.push([W-c[0],c[1]]);});
const trail=(a,b,seed)=>{
const rr=mul(seed),mx=(a[0]+b[0])/2+(rr()-.5)*120,my=(a[1]+b[1])/2+(rr()-.5)*120;
[[46,'rgba(30,24,14,.28)'],[34,'rgba(88,70,44,.55)'],[22,'rgba(116,94,60,.45)']].forEach(s=>{
g.lineWidth=s[0];g.strokeStyle=s[1];g.lineCap='round';g.beginPath();g.moveTo(a[0],a[1]);g.quadraticCurveTo(mx,my,b[0],b[1]);g.stroke();});
for(let i=0;i<22;i++){const t=r(),u=1-t,px=u*u*a[0]+2*u*t*mx+t*t*b[0]+(r()-.5)*44,py=u*u*a[1]+2*u*t*my+t*t*b[1]+(r()-.5)*44;ell(g,px,py,2+r()*3,1.5+r()*2,r()*3,'rgba(150,130,100,.5)');}
};
const links=[[1,0],[0,2],[2,3],[5,4],[4,6],[6,7]];
for(const side of [0,1]){
const tr=p=>side?[W-p[0],p[1]]:p;
links.forEach((l,i)=>trail(tr(CPS[l[0]]),tr(CPS[l[1]]),100+i+side*10));
trail(tr(CPS[3]),side?[W-SPT[0]+0,SPT[1]]:SPT,200+side);
trail(tr(CPS[7]),side?[W-DPT[0],DPT[1]]:DPT,210+side);
trail(tr(CPS[0]),tr([1050,1350]),220+side);
trail(tr(CPS[4]),tr([1050,1350]),230+side);
}
all.forEach((c,i)=>{
const rr=mul(500+i);
let gg=g.createRadialGradient(c[0],c[1],10,c[0],c[1],92);
gg.addColorStop(0,'rgba(120,98,64,.78)');gg.addColorStop(.7,'rgba(96,78,50,.6)');gg.addColorStop(1,'rgba(96,78,50,0)');
g.fillStyle=gg;g.beginPath();g.arc(c[0],c[1],92,0,7);g.fill();
for(let k=0;k<22;k++){const a=k/22*6.2832+rr()*.3,d=70+rr()*14;ell(g,c[0]+Math.cos(a)*d,c[1]+Math.sin(a)*d,6+rr()*5,4+rr()*3,a,'rgba(120,124,118,.8)');ell(g,c[0]+Math.cos(a)*d-1,c[1]+Math.sin(a)*d-1.5,3,2,a,'rgba(190,195,190,.5)');}
for(let k=0;k<14;k++){const a=rr()*6.28,d=rr()*60;ell(g,c[0]+Math.cos(a)*d,c[1]+Math.sin(a)*d,2+rr()*3,1.5+rr()*2,rr()*3,'rgba(60,46,28,.5)');}
});
// grass tufts, batched by colour
const tc=['#3b6a3f','#2d5a36','#4f8a4a','#6aa35a','#1c3f27'];
for(let c=0;c<tc.length;c++){
g.strokeStyle=tc[c];g.lineWidth=1.6;g.globalAlpha=c>2?.5:.6;g.beginPath();
for(let i=0;i<2600;i++){
const x=r()*W,y=r()*H,h=5+r()*7;
g.moveTo(x,y);g.lineTo(x-2.5,y-h);g.moveTo(x,y);g.lineTo(x+.5,y-h-2);g.moveTo(x,y);g.lineTo(x+3,y-h+1);
}
g.stroke();
}
g.globalAlpha=1;
// flower clusters
const fc=['#ffd9e8','#fff3a8','#c8defe','#ffb08a','#e9c8ff'];
for(let i=0;i<260;i++){
const x=r()*W,y=r()*H,c=fc[(r()*5)|0],n=3+((r()*5)|0);
for(let k=0;k<n;k++){const fx=x+(r()-.5)*46,fy=y+(r()-.5)*30;ell(g,fx,fy,3.2,3.2,0,c);ell(g,fx,fy,1.2,1.2,0,'#e8b33a');}
}
// pebbles & boulders
for(let i=0;i<520;i++){const x=r()*W,y=r()*H,s=2+r()*4;ell(g,x+1,y+1.5,s*1.2,s*.7,0,'rgba(0,0,0,.28)');ell(g,x,y,s*1.2,s*.8,0,'#6f766f');ell(g,x-.8,y-1,s*.6,s*.4,0,'#a0a79f');}
for(let i=0;i<70;i++){
const x=r()*W,y=r()*H,s=12+r()*16;
ell(g,x+s*.2,y+s*.5,s*1.5,s*.7,0,'rgba(0,0,0,.3)');
ell(g,x,y,s*1.25,s*.95,r(),'#4f564f');ell(g,x-s*.2,y-s*.2,s*.85,s*.6,r(),'#6a726a');ell(g,x-s*.35,y-s*.35,s*.4,s*.25,0,'#9aa29a');
if(r()<.5){ell(g,x+s*.4,y-s*.5,s*.5,s*.25,0,'#3f7a45');}
}
// ---------- RIVER ----------
wavy(g,2330,2470,10,1.2,'rgba(30,24,14,.35)');
wavy(g,2338,2462,9,1.5,'#4a4430');
wavy(g,2346,2454,7,1.9,'#6e6446');
wavy(g,2356,2444,6,2.3,'#17435d');
let rg=g.createLinearGradient(2356,0,2444,0);
rg.addColorStop(0,'#123850');rg.addColorStop(.5,'#2a77a0');rg.addColorStop(1,'#123850');
wavy(g,2364,2436,5,2.6,rg);
g.globalAlpha=.55;
for(let i=0;i<420;i++){const x=2372+r()*56,y=r()*H,l=10+r()*26;g.strokeStyle=r()<.5?'#8ccbe6':'#4a9cc4';g.lineWidth=1.5;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+4,y+l/2,x-1,y+l);g.stroke();}
g.globalAlpha=.4;g.strokeStyle='#fff';g.lineWidth=2;g.setLineDash([14,18]);
for(const xs of [2362,2438]){g.beginPath();for(let y=-20;y<=H+20;y+=24)g.lineTo(xs+Math.sin(y*.011+2.6)*5,y);g.stroke();}
g.setLineDash([]);g.globalAlpha=1;
// reeds + lily pads
for(let i=0;i<260;i++){
const side=i%2?1:-1,y=r()*H,x=2400+side*(52+r()*8)+Math.sin(y*.011)*8,h=14+r()*16;
g.strokeStyle=r()<.5?'#3f7a3a':'#5a9a46';g.lineWidth=1.8;g.beginPath();
for(let k=-1;k<=1;k++){g.moveTo(x+k*3,y);g.lineTo(x+k*4+side*2,y-h+Math.abs(k)*4);}
g.stroke();
if(r()<.35){ell(g,x+1,y-h,2,4,0,'#6b4a2a');}
}
for(let i=0;i<70;i++){
const x=2380+r()*40,y=r()*H,s=6+r()*5;
ell(g,x+1,y+1,s,s*.75,0,'rgba(0,0,0,.25)');ell(g,x,y,s,s*.75,0,'#3f8f4a');ell(g,x-1,y-1,s*.6,s*.4,0,'#5fb35a');
if(r()<.3)ell(g,x+2,y-1,2.4,2.4,0,'#ffc6dd');
}
// crab shoals (sand bars) in the river
[[2400,560],[2400,2140]].forEach(p=>{
let sg=g.createRadialGradient(p[0],p[1],8,p[0],p[1],74);sg.addColorStop(0,'#cdbb86');sg.addColorStop(.75,'#a8976a');sg.addColorStop(1,'rgba(168,151,106,0)');
g.fillStyle=sg;g.beginPath();g.ellipse(p[0],p[1],74,60,0,0,7);g.fill();
for(let k=0;k<10;k++){const a=r()*6.28,d=r()*44;ell(g,p[0]+Math.cos(a)*d,p[1]+Math.sin(a)*d,3,2,a,k%2?'#f3d7c4':'#e1a58a');}
});
// ---------- MAP-EDGE CLIFFS ----------
g.fillStyle='#0f1612';g.fillRect(0,0,W,34);g.fillRect(0,H-34,W,34);g.fillRect(0,0,34,H);g.fillRect(W-34,0,34,H);
let eg=g.createLinearGradient(0,34,0,190);eg.addColorStop(0,'rgba(0,0,0,.5)');eg.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=eg;g.fillRect(0,34,W,160);
eg=g.createLinearGradient(0,H-34,0,H-190);eg.addColorStop(0,'rgba(0,0,0,.5)');eg.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=eg;g.fillRect(0,H-190,W,156);
eg=g.createLinearGradient(34,0,190,0);eg.addColorStop(0,'rgba(0,0,0,.5)');eg.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=eg;g.fillRect(34,0,156,H);
eg=g.createLinearGradient(W-34,0,W-190,0);eg.addColorStop(0,'rgba(0,0,0,.5)');eg.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=eg;g.fillRect(W-190,0,156,H);
const rocks=['#1a241d','#222e25','#2c3a30','#38483b'];
for(let i=0;i<520;i++){
const s=14+r()*30,side=i%4;let x,y;
if(side===0){x=r()*W;y=r()*30;}else if(side===1){x=r()*W;y=H-r()*30;}else if(side===2){x=r()*30;y=r()*H;}else{x=W-r()*30;y=r()*H;}
const c=rocks[(r()*4)|0];ell(g,x,y+4,s,s*.7,r(),'rgba(0,0,0,.35)');ell(g,x,y,s,s*.75,r(),c);ell(g,x-s*.25,y-s*.25,s*.5,s*.3,0,'rgba(255,255,255,.08)');
}
}

/* ---------- OVERLAY (over lanes, under units) ---------- */
function buildOV(){
OV=mk(MW,MH);const g=OV.getContext('2d');g.scale(S,S);const r=mul(4242);
g.lineJoin='round';g.lineCap='round';
const lanes=PA[0];
// team tint along the lanes
let tg=g.createLinearGradient(0,0,W,0);
tg.addColorStop(0,'rgba(59,130,246,.20)');tg.addColorStop(.3,'rgba(59,130,246,.06)');tg.addColorStop(.5,'rgba(0,0,0,0)');tg.addColorStop(.7,'rgba(229,72,77,.06)');tg.addColorStop(1,'rgba(229,72,77,.20)');
g.strokeStyle=tg;g.lineWidth=96;
lanes.forEach(l=>{g.beginPath();l.forEach((q,i)=>g[i?'lineTo':'moveTo'](q[0],q[1]));g.stroke();});
// cobble / dirt stones
const sc=['rgba(120,108,80,.55)','rgba(88,78,56,.6)','rgba(136,124,96,.45)','rgba(62,55,40,.6)','rgba(150,140,118,.4)'];
lanes.forEach((l,li)=>{
const pts=samp(l,9),rr=mul(900+li);
pts.forEach((p,i)=>{
for(let k=0;k<3;k++){
const o=(rr()-.5)*88,x=p.x+p.nx*o,y=p.y+p.ny*o,rot=Math.atan2(p.ty,p.tx)+(rr()-.5)*.8;
ell(g,x,y,3+rr()*5,2+rr()*3,rot,sc[(rr()*5)|0]);
}
});
// worn centre line
g.strokeStyle='rgba(255,240,200,.07)';g.lineWidth=5;g.setLineDash([26,22]);g.beginPath();l.forEach((q,i)=>g[i?'lineTo':'moveTo'](q[0],q[1]));g.stroke();g.setLineDash([]);
// edge kerb stones
const ed=samp(l,19);
ed.forEach((p,i)=>{
for(const sd of [-1,1]){
const o=sd*(54+(rr()-.5)*3),x=p.x+p.nx*o,y=p.y+p.ny*o,rot=Math.atan2(p.ty,p.tx);
ell(g,x+1,y+2,9,6,rot,'rgba(0,0,0,.35)');ell(g,x,y,8.5,5.5,rot,'#6e7479');ell(g,x-1,y-1.5,5,2.6,rot,'#a3aab0');
}
});
// torches
let acc=0;
for(let i=0;i<pts.length;i++){
acc+=9;
if(acc>=430){acc=0;const p=pts[i];
if(Math.hypot(p.x-320,p.y-1350)<330||Math.hypot(p.x-(W-320),p.y-1350)<330||Math.abs(p.x-2400)<130)continue;
const sd=(TORCH.length%2)?1:-1;TORCH.push({x:p.x+p.nx*66*sd,y:p.y+p.ny*66*sd,c:'#ff9f43'});}
}
});
TORCH.forEach(t=>{ell(g,t.x+2,t.y+8,6,3,0,'rgba(0,0,0,.35)');g.fillStyle='#3a2a1a';g.fillRect(t.x-2,t.y-8,4,16);g.fillStyle='#5b4430';g.fillRect(t.x-2,t.y-8,1.5,16);ell(g,t.x,t.y-10,6.5,4,0,'#2a2a2e');ell(g,t.x,t.y-11,4.5,2.6,0,'#4a3a2a');});
// bridges over the river
[360,1350,2340].forEach(y=>{
const x0=2328,w=144,h=124,y0=y-h/2;
g.fillStyle='rgba(0,0,0,.35)';g.fillRect(x0+5,y0+9,w,h);
g.fillStyle='#6d4c2b';g.fillRect(x0,y0,w,h);
for(let x=x0;x<x0+w;x+=14){g.fillStyle=((x-x0)/14|0)%2?'#7e5a34':'#6a4a29';g.fillRect(x,y0,13,h);g.fillStyle='rgba(0,0,0,.28)';g.fillRect(x+13,y0,1.5,h);g.fillStyle='rgba(255,230,180,.08)';g.fillRect(x,y0,13,2);}
for(let k=0;k<26;k++){const x=x0+4+r()*(w-8),yy=y0+4+r()*(h-8);ell(g,x,yy,1.5,1.5,0,'#2b1d10');}
g.fillStyle='#46301d';g.fillRect(x0-8,y0-7,w+16,10);g.fillRect(x0-8,y0+h-3,w+16,10);
g.fillStyle='#7a5a38';g.fillRect(x0-8,y0-7,w+16,3);g.fillRect(x0-8,y0+h-3,w+16,3);
for(const px of [x0-4,x0+w/2-4,x0+w-4])for(const py of [y0-11,y0+h-1]){g.fillStyle='#2f2013';g.fillRect(px,py,9,12);g.fillStyle='#8a6a42';g.fillRect(px,py,9,3);}
});
// pits (serpent / dragon)
[[SPT,'#b44dff','#2a1040'],[DPT,'#ff9f43','#401a08']].forEach(([p,col,dk])=>{
const x=p[0],y=p[1],R=122;
ell(g,x+6,y+10,R+10,R*.9,0,'rgba(0,0,0,.35)');
g.fillStyle='#161a18';g.beginPath();g.arc(x,y,R+6,0,7);g.fill();
let pg=g.createRadialGradient(x,y,6,x,y,R);pg.addColorStop(0,dk);pg.addColorStop(.7,'#0f1612');pg.addColorStop(1,'#1d2a22');
g.fillStyle=pg;g.beginPath();g.arc(x,y,R,0,7);g.fill();
g.strokeStyle=col;g.globalAlpha=.55;g.lineWidth=3;g.beginPath();g.arc(x,y,R-12,0,7);g.stroke();g.lineWidth=1.5;g.beginPath();g.arc(x,y,R-34,0,7);g.stroke();
for(let k=0;k<12;k++){const a=k/12*6.2832;g.lineWidth=3;g.beginPath();g.moveTo(x+Math.cos(a)*(R-30),y+Math.sin(a)*(R-30));g.lineTo(x+Math.cos(a)*(R-18),y+Math.sin(a)*(R-18));g.stroke();}
g.globalAlpha=1;
for(let k=0;k<30;k++){const a=k/30*6.2832,d=R+8,sx=x+Math.cos(a)*d,sy=y+Math.sin(a)*d,s=10+(k%3)*3;
ell(g,sx+2,sy+3,s,s*.7,a,'rgba(0,0,0,.35)');ell(g,sx,sy,s,s*.72,a,'#59605a');ell(g,sx-2,sy-2,s*.55,s*.35,a,'#8d958d');}
for(const q of [0,1,2,3]){const a=q*1.5708+.785,sx=x+Math.cos(a)*(R+30),sy=y+Math.sin(a)*(R+30);
g.fillStyle='#32363a';g.fillRect(sx-8,sy-8,16,16);g.fillStyle='#565c63';g.fillRect(sx-8,sy-8,16,5);ell(g,sx,sy-10,5,3.5,0,col);}
});
// base plazas
[[B[0],'#3b82f6'],[B[1],'#e5484d']].forEach(([b,col],ti)=>{
const x=b.x,y=b.y,R=232;
ell(g,x+8,y+12,R+8,R,0,'rgba(0,0,0,.35)');
let pg=g.createRadialGradient(x,y,20,x,y,R);pg.addColorStop(0,'#555b63');pg.addColorStop(.8,'#3b4048');pg.addColorStop(1,'#2d3238');
g.fillStyle=pg;g.beginPath();g.arc(x,y,R,0,7);g.fill();
g.strokeStyle='rgba(0,0,0,.35)';g.lineWidth=2;
for(let rad=44;rad<R;rad+=38){g.beginPath();g.arc(x,y,rad,0,7);g.stroke();}
const sp=28;for(let k=0;k<sp;k++){const a=k/sp*6.2832;g.beginPath();g.moveTo(x+Math.cos(a)*44,y+Math.sin(a)*44);g.lineTo(x+Math.cos(a)*R,y+Math.sin(a)*R);g.stroke();}
for(let i=0;i<260;i++){const a=r()*6.28,d=30+r()*(R-40);ell(g,x+Math.cos(a)*d,y+Math.sin(a)*d,3+r()*5,2+r()*3,a,r()<.5?'rgba(255,255,255,.04)':'rgba(0,0,0,.08)');}
g.strokeStyle=col;g.globalAlpha=.5;g.lineWidth=7;g.beginPath();g.arc(x,y,190,0,7);g.stroke();g.lineWidth=3;g.beginPath();g.arc(x,y,128,0,7);g.stroke();
g.globalAlpha=.16;g.fillStyle=col;g.beginPath();
for(let k=0;k<16;k++){const a=k/16*6.2832-1.5708,rad=k%2?90:176;g.lineTo(x+Math.cos(a)*rad,y+Math.sin(a)*rad);}
g.closePath();g.fill();g.globalAlpha=1;
g.strokeStyle='#14171b';g.lineWidth=10;g.beginPath();g.arc(x,y,R,0,7);g.stroke();
g.strokeStyle='rgba(180,190,200,.45)';g.lineWidth=2;g.beginPath();g.arc(x,y,R-6,0,7);g.stroke();
for(let q=0;q<8;q++){
const a=q*.7854+.3927,px=x+Math.cos(a)*(R-8),py=y+Math.sin(a)*(R-8),big=q%2===0;
ell(g,px+3,py+5,12,8,0,'rgba(0,0,0,.4)');
g.fillStyle='#262b31';g.fillRect(px-11,py-11,22,22);g.fillStyle='#4d555e';g.fillRect(px-11,py-11,22,6);g.fillStyle=col;g.globalAlpha=.7;g.fillRect(px-11,py+6,22,5);g.globalAlpha=1;
ell(g,px,py-12,8,5,0,'#1c1f23');ell(g,px,py-13,5.5,3,0,'#3a2a1a');
if(big)BRZ.push({x:px,y:py-14,c:ti?'#ff6a5a':'#5aa8ff'});
}
});
}

function ensure(){
if(BUILT||FAIL)return;
try{buildBG();buildOV();BUILT=true;}catch(e){FAIL=true;BG=OV=null;console.error('Map detail failed',e);}
}
function blit(c){
const vw=cv.width/dpr/z,vh=cv.height/dpr/z;
const sx=Math.max(0,Math.floor(cx)),sy=Math.max(0,Math.floor(cy)),ex=Math.min(W,Math.ceil(cx+vw)),ey=Math.min(H,Math.ceil(cy+vh));
if(ex<=sx||ey<=sy)return;
const sm=X.imageSmoothingEnabled;X.imageSmoothingEnabled=true;
X.drawImage(c,sx*S,sy*S,(ex-sx)*S,(ey-sy)*S,sx,sy,ex-sx,ey-sy);
X.imageSmoothingEnabled=sm;
}
const fr=n=>{const s=Math.sin(n*12.9898)*43758.5453;return s-Math.floor(s)};
function vis(x,y,m){const vw=cv.width/dpr/z,vh=cv.height/dpr/z;return x>cx-m&&x<cx+vw+m&&y>cy-m&&y<cy+vh+m;}

/* ---------- LIVE DETAIL (bushes, trees, walls, flames, ripples) ---------- */
function top(){
const t=(G&&G.t)||0;
// walls: stone bricks + moss
WL.forEach((w,wi)=>{
if(!vis(w[0]+w[2]/2,w[1]+w[3]/2,200))return;
const x=w[0],y=w[1],ww=w[2],hh=w[3];
X.fillStyle='#3d4a42';X.fillRect(x,y,ww,hh);
X.fillStyle='rgba(255,255,255,.07)';X.fillRect(x,y,ww,5);
X.fillStyle='rgba(0,0,0,.22)';X.fillRect(x,y+hh-6,ww,6);
X.strokeStyle='rgba(10,18,14,.55)';X.lineWidth=1.5;X.beginPath();
for(let row=0;row<4;row++){const yy=y+row*11;X.moveTo(x,yy);X.lineTo(x+ww,yy);const off=row%2?0:14;for(let bx=x+off;bx<x+ww;bx+=28){X.moveTo(bx,yy);X.lineTo(bx,yy+11);}}
X.stroke();
for(let k=0;k<9;k++){const mx=x+fr(wi*13+k)*ww,my=y+fr(wi*7+k*3)*8;X.fillStyle='rgba(80,150,70,.55)';X.beginPath();X.ellipse(mx,my,6+fr(k+wi)*6,3,0,0,7);X.fill();}
X.strokeStyle='#162119';X.lineWidth=6;X.strokeRect(x,y,ww,hh);
});
// bushes
BS.forEach((b,i)=>{
if(!vis(b[0],b[1],b[2]+40))return;
const R=b[2],n=Math.round(R/6)+6;
X.fillStyle='rgba(8,24,14,.45)';X.beginPath();X.arc(b[0],b[1],R+3,0,7);X.fill();
for(let k=0;k<n;k++){
const a=k*2.399+i,rad=R*(.28+.62*fr(k*3.1+i)),sw=Math.sin(t*1.3+k+i)*1.6,lr=R*.2+fr(k+i*5)*R*.1;
X.fillStyle=['#245a31','#2d6b3a','#38804a','#1f4e2b'][k&3];
X.beginPath();X.ellipse(b[0]+Math.cos(a)*rad+sw,b[1]+Math.sin(a)*rad,lr*1.15,lr*.85,a,0,7);X.fill();
}
for(let k=0;k<n;k++){const a=k*2.399+i,rad=R*(.28+.62*fr(k*3.1+i)),sw=Math.sin(t*1.3+k+i)*1.6;X.fillStyle='rgba(180,255,170,.13)';X.beginPath();X.ellipse(b[0]+Math.cos(a)*rad+sw-3,b[1]+Math.sin(a)*rad-4,R*.1,R*.06,a,0,7);X.fill();}
for(let k=0;k<7;k++){const a=fr(k+i*9)*6.28,rad=R*.8*fr(k*2+i);X.fillStyle=['#ffe08a','#ffc6dd','#fff'][k%3];X.beginPath();X.arc(b[0]+Math.cos(a)*rad,b[1]+Math.sin(a)*rad,2.6,0,7);X.fill();}
X.strokeStyle='#10281a';X.lineWidth=4;X.beginPath();X.arc(b[0],b[1],R,0,7);X.stroke();
X.strokeStyle='rgba(120,220,120,.18)';X.lineWidth=2;X.beginPath();X.arc(b[0],b[1],R-5,0,7);X.stroke();
});
// trees
for(let i=0;i<TR.length;i++){
const q=TR[i],x=q[0],y=q[1],r=q[2];
if(!vis(x,y,60))continue;
const sway=Math.sin(t*.9+i)*1.2;
X.fillStyle='rgba(0,0,0,.28)';X.beginPath();X.ellipse(x+r*.35,y+r*.5,r*1.1,r*.7,0,0,7);X.fill();
X.fillStyle='#0d2614';X.beginPath();X.arc(x,y,r*1.08,0,7);X.fill();
X.fillStyle='#17421f';X.beginPath();X.arc(x+sway*.3,y-r*.06,r*.9,0,7);X.fill();
X.fillStyle='#235c2e';X.beginPath();X.arc(x-r*.12+sway*.6,y-r*.16,r*.62,0,7);X.fill();
X.fillStyle='#34803f';X.beginPath();X.arc(x-r*.25+sway,y-r*.28,r*.34,0,7);X.fill();
X.fillStyle='rgba(200,255,180,.2)';X.beginPath();X.arc(x-r*.32+sway,y-r*.36,r*.14,0,7);X.fill();
}
// river ripples
if(cx<2480&&cx+cv.width/dpr/z>2320){
const y0=Math.max(0,Math.floor(cy/70)*70),y1=Math.min(H,cy+cv.height/dpr/z+70);
X.lineWidth=2;X.lineCap='round';
for(let yy=y0;yy<y1;yy+=70){
const k=yy/70,ph=t*1.2+k*1.7,a=.18+.14*Math.sin(ph),x=2384+fr(k)*32;
X.strokeStyle='rgba(200,235,250,'+a.toFixed(3)+')';
X.beginPath();X.moveTo(x-9,yy+Math.sin(ph)*3);X.quadraticCurveTo(x,yy-3+Math.sin(ph)*3,x+9,yy+Math.sin(ph)*3);X.stroke();
}
}
// pit glow pulse
[[SPT,'180,77,255'],[DPT,'255,159,67']].forEach(([p,c])=>{
if(!vis(p[0],p[1],160))return;
const a=.10+.07*Math.sin(t*2.2);
X.fillStyle='rgba('+c+','+a.toFixed(3)+')';X.beginPath();X.arc(p[0],p[1],100,0,7);X.fill();
});
// flames: lane torches + base braziers
const fl=(x,y,c,sz)=>{
const f=Math.sin(t*14+x*.13+y*.07)*.5+.5,h=sz*(1.1+f*.7);
X.fillStyle=c==='#ff9f43'?'rgba(255,170,70,.12)':(c==='#5aa8ff'?'rgba(90,170,255,.13)':'rgba(255,100,80,.13)');
X.beginPath();X.arc(x,y-3,sz*4.2+f*3,0,7);X.fill();
X.fillStyle=c;X.beginPath();X.moveTo(x-sz,y);X.quadraticCurveTo(x-sz*.9,y-h*.7,x+Math.sin(t*9+x)*1.5,y-h*1.5);X.quadraticCurveTo(x+sz*.9,y-h*.7,x+sz,y);X.closePath();X.fill();
X.fillStyle='#ffe27a';X.beginPath();X.moveTo(x-sz*.5,y);X.quadraticCurveTo(x,y-h*.9,x+sz*.5,y);X.closePath();X.fill();
};
TORCH.forEach(q=>{if(vis(q.x,q.y,60))fl(q.x,q.y-12,q.c,5);});
BRZ.forEach(q=>{if(vis(q.x,q.y,60))fl(q.x,q.y-2,q.c,6);});
}

window.MAPD={
bg(){if(window.BAL_RUN)return;ensure();if(BG)blit(BG);},
ov(){if(window.BAL_RUN||!OV)return;blit(OV);},
top(){if(window.BAL_RUN||FAIL)return;try{X.save();top();}catch(e){}finally{X.restore();}}
};
})();}catch(err){console.error('Map detail pack failed',err);}
